export const DB_NAME = "Rectify-Code"
